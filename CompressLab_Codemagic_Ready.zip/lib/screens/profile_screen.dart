import 'package:compresslab/helper/helperku.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/material.dart';
import 'package:line_awesome_flutter/line_awesome_flutter.dart';
import 'package:package_info_plus/package_info_plus.dart';
import 'package:shared_preferences/shared_preferences.dart';


class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {

    Future<String> getAppVersion() async {
      final PackageInfo packageInfo = await PackageInfo.fromPlatform();
      return '${packageInfo.version} (${packageInfo.buildNumber})';
    }



    Future<String?> _loadName() async{
      final prefs = await SharedPreferences.getInstance();
     return prefs.getString('nama');
    }
    final DeviceInfoPlugin deviceInfoPlugin = DeviceInfoPlugin();
     Map<String, dynamic> _deviceData = <String, dynamic>{};
    var isDark = MediaQuery.of(context).platformBrightness == Brightness.dark;
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile', style: Theme.of(context).textTheme.headline6),
        centerTitle: true,
        // actions: [
        //   IconButton(
        //     onPressed: () {},
        //     icon: Icon(isDark ? LineAwesomeIcons.sun : LineAwesomeIcons.moon),
        //   ),
        // ],
      ),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(20.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              /// -- IMAGE
              Stack(
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundImage: AssetImage("assets/app_icon.png"),
                  ),
                  Positioned(
                    bottom: 0,
                    right: 4,
                    child: Container(
                      width: 35,
                      height: 35,
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(100),
                        color: Theme.of(context).colorScheme.secondary,
                      ),
                      child: Icon(
                        LineAwesomeIcons.alternate_pencil,
                        color: Colors.white,
                        size: 20,
                      ),
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 20),
              FutureBuilder(
                future: _loadName(),
                builder:(context,snapshot){
                  return Text(
                    '${snapshot.data}',
                    style: TextStyle(
                        color: Colors.black, fontWeight: FontWeight.bold
                    ),
                  );
                }

              ),
              const SizedBox(height: 5),
              // Text(
              //   'Poin: 12',
              //   style: TextStyle(
              //     color: Colors.black, fontWeight: FontWeight.bold
              //   ),
              // ),
              const SizedBox(height: 30),
              Divider(),
              const SizedBox(height: 20),
              /// -- MENU
    /// -- MENU
    FutureBuilder<String>(
    future: getAppVersion(),
    builder: (context, snapshot) {
    if (snapshot.connectionState == ConnectionState.waiting) {
    return ListTile(
    leading: Icon(LineAwesomeIcons.info_circle),
    title: Text('App Version'),
    subtitle: Text("Loading..."),
    );
    } else if (snapshot.hasError) {
    return ListTile(
    leading: Icon(LineAwesomeIcons.info_circle),
    title: Text('App Version'),
    subtitle: Text("Error: ${snapshot.error}"),
    );
    } else {
    return ListTile(
    leading: Icon(LineAwesomeIcons.info_circle),
    title: Text('App Version'),
    subtitle: Text('${snapshot.data}' ?? 'Unknown')
    );
    }
    },
    ),

              // ListTile(
              //   leading: Icon(LineAwesomeIcons.envelope),
              //   title: Text('App Version'),
              //   subtitle: Text("${deviceInfoPlugin.deviceInfo}"),
              // ),
              ListTile(
                leading: Icon(LineAwesomeIcons.envelope),
                title: Text('Contact Us'),
                subtitle: Text("synelab.official@gmail.com"),
              ),
            ],
          ),
        ),
      ),
    );
  }
}