import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_file_dialog/flutter_file_dialog.dart';
import 'package:path_provider/path_provider.dart';

class ImagePreview extends StatelessWidget {
  final File imageFile;
  final File? compressedFile;

  const ImagePreview({Key? key, required this.imageFile, this.compressedFile}) : super(key: key);



  Future<void> saveFile(File file, String fileName) async{
    final directory = await getExternalStorageDirectory();
    final path = directory!.path;

    final File newFile = File('$path/$fileName');

    if(await newFile.exists()){
      await newFile.delete();
    }


    await newFile.writeAsBytes(await file.readAsBytes());

    final params = SaveFileDialogParams(sourceFilePath:  newFile.path);
    await FlutterFileDialog.saveFile(params: params);
  }
  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      insetPadding: const EdgeInsets.all(10),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,

        children: [
          Expanded(
            child: Hero(
              tag: imageFile.path,
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(15),
                  image: DecorationImage(
                    image: FileImage(imageFile),
                    fit: BoxFit.cover,
                  ),
                ),
              ),
            ),
          ),
          if(compressedFile != null)
            Expanded(
                child:
         Hero(tag: compressedFile!.path  , child:
         Container(
           decoration: BoxDecoration(
             borderRadius: BorderRadius.circular(15),
             image: DecorationImage(
               image: FileImage(compressedFile!),
              fit: BoxFit.cover,
             )
           ),
         ))
            ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              ElevatedButton(
                onPressed: () => saveFile(imageFile, 'original_image.jpg'),
                child: const Text('Download Original'),
              ),
              if (compressedFile != null)
                ElevatedButton(
                  onPressed: () => saveFile(compressedFile!, 'compressed_image.jpg'),
                  child: const Text('Download Compressed'),
                ),
            ],
          ),
        ],
      ),
    );
  }
}
