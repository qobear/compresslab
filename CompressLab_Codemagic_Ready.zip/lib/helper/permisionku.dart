import 'package:flutter/material.dart';
import 'package:permission_handler/permission_handler.dart';

Future<void> requestPermissions(BuildContext context) async {
  // // Check if the permission is already granted
  // if (await Permission.storage.isGranted) {
  //   // Permissions are already granted, continue
  //   print("Storage permissions are already granted.");
  // } else {
  //   // Request the storage permissions
  //   PermissionStatus status = await Permission.storage.request();
  //   if (status.isGranted) {
  //     // Permissions are granted, continue
  //     print("Storage permissions granted.");
  //   } else if (status.isDenied) {
  //     // Permissions are denied, handle appropriately
  //     print("Storage permissions denied.");
  //     showPermissionDeniedDialog(context);
  //   } else if (status.isPermanentlyDenied) {
  //     // Permissions are permanently denied, open app settings
  //     print("Storage permissions permanently denied.");
  //     showPermissionPermanentlyDeniedDialog(context);
  //   }
  // }
  // For Android 13 and above, request new media permissions
  if (await Permission.photos.request().isGranted &&
      await Permission.videos.request().isGranted &&
      await Permission.audio.request().isGranted) {
    // Permissions are granted, you can perform your file operations
  } else {
    // Handle the case where permissions are denied
    openAppSettings();
    print("Storage permissions are required to perform this operation.");
  }
}

void showPermissionDeniedDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) => AlertDialog(
      title: const Text("Storage Permission Needed"),
      content: const Text(
          "This app needs storage access to select and compress images. Please grant the permission."),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
            requestPermissions(context); // Re-request permissions
          },
          child: const Text("Retry"),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text("Cancel"),
        ),
      ],
    ),
  );
}

void showPermissionPermanentlyDeniedDialog(BuildContext context) {
  showDialog(
    context: context,
    builder: (BuildContext context) => AlertDialog(
      title: const Text("Storage Permission Needed"),
      content: const Text(
          "This app needs storage access to select and compress images. Please grant the permission in settings."),
      actions: <Widget>[
        TextButton(
          onPressed: () {
            Navigator.of(context).pop();
            openAppSettings();
          },
          child: const Text("Open Settings"),
        ),
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text("Cancel"),
        ),
      ],
    ),
  );
}
