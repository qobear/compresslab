package com.synelab.complab

import android.media.MediaScannerConnection
import android.os.Bundle
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val CHANNEL = "plugins.flutter.io/path_provider"

    override fun configureFlutterEngine(@NonNull flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL).setMethodCallHandler { call, result ->
            if (call.method == "scanFile") {
                val path: String? = call.argument("path")
                if (path != null) {
                    scanFile(path)
                    result.success(null)
                } else {
                    result.error("INVALID_ARGUMENT", "Path argument is null", null)
                }
            } else {
                result.notImplemented()
            }
        }
    }

    private fun scanFile(path: String) {
        MediaScannerConnection.scanFile(this, arrayOf(path), null) { path, uri ->
            // Scanned successfully
        }
    }
}