import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';

import '../helper/license_provider.dart';
import '../helper/settings_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final settingsProvider = Provider.of<SettingsProvider>(context);
    final licenseProvider = Provider.of<LicenseProvider>(context);
    final TextEditingController licenseController = TextEditingController(
      text: licenseProvider.licenseCode ?? '',
    );

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings', style: TextStyle(color: Colors.white),),
        backgroundColor: Theme.of(context).colorScheme.secondary,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    TextField(
                      controller: licenseController,
                      decoration:  InputDecoration(
                        enabledBorder: OutlineInputBorder(
                          borderSide: BorderSide(color: Theme.of(context).colorScheme.secondary),
                        ),
                        labelText: 'Kode Lisensi',
                        border: OutlineInputBorder(
                          borderSide: BorderSide(color: Colors.black26,width: 2.0,style: BorderStyle.solid)
                        ),
                      ),
                    ),
                    const SizedBox(height: 10),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        primary: Theme.of(context).colorScheme.secondary,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10.0),
                        ),
                      ),
                      onPressed: () async {
                        await licenseProvider.checkLicense(licenseController.text);
                        if (licenseProvider.isLicensed) {
                          showDialog(
                            context: context,
                            builder: (context) =>  AlertDialog(
                              title: Text('License Active'),
                              content: Text(
                                  'Terimakasi Lisensi Sudah Aktif.'),
                            ),
                          );
                        } else {
                          showDialog(
                            context: context,
                            builder: (context) => AlertDialog(
                              title: const Text('Invalid License'),
                              content: const Text(
                                  'The license code you entered is invalid. Please try again.'),
                              actions: [
                                TextButton(
                                  onPressed: () => Navigator.pop(context),
                                  child: const Text('OK'),
                                ),
                              ],
                            ),
                          );
                        }
                      },
                      child: const Text('Submit License Code', style: TextStyle(color: Colors.white)),
                    ),
                    if (licenseProvider.isLicensed)
                    Text('Lisensi Aktive', style: TextStyle(color: Colors.black, fontWeight: FontWeight.bold),)
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Compression Level: ${settingsProvider.settings.compressionLevel.toInt()}%',
                      style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),
                    ),
                    Slider(
                      value: settingsProvider.settings.compressionLevel,
                      min: 10,
                      max: 100,
                      thumbColor: Colors.black,
                      activeColor: Colors.black45,
                      divisions: 90,
                      label: '${settingsProvider.settings.compressionLevel.toInt()}%',
                      onChanged: (value) {
                        settingsProvider.updateCompressionLevel(value);
                      },
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            Card(
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    SwitchListTile(
                      title: const Text('Enable Width and Height',style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold, color: Colors.black),),
                      value: settingsProvider.isWidthHeightEnabled,
                      onChanged: (value) {
                        settingsProvider.toggleWidthHeightEnabled(value);
                      },
                      inactiveTrackColor: Theme.of(context).colorScheme.secondary,
                      inactiveThumbColor: Colors.white,
                    ),
                    if (settingsProvider.isWidthHeightEnabled) ...[
                      const SizedBox(height: 10),
                      Text(
                        'Width: ${settingsProvider.settings.width ?? 0} px',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                      ),
                      Slider(
                        value: (settingsProvider.settings.width ?? 320).toDouble(),
                        min: 320,
                        max: 1920,
                        divisions: 160,
                        label: '${settingsProvider.settings.width ?? 320} px',
                        thumbColor: Colors.black,
                        activeColor: Colors.black45,
                        onChanged: (value) {
                          settingsProvider.updateWidth(value.toInt());
                        },
                      ),
                      const SizedBox(height: 10),
                      Text(
                        'Height: ${settingsProvider.settings.height ?? 480} px',
                        style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
                      ),
                      Slider(
                        value: (settingsProvider.settings.height ?? 480).toDouble(),
                        min: 480,
                        max: 1920,
                        divisions: 144,
                        thumbColor: Colors.black,
                        activeColor: Colors.black45,
                        label: '${settingsProvider.settings.height ?? 480} px',
                        onChanged: (value) {
                          settingsProvider.updateHeight(value.toInt());
                        },
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}