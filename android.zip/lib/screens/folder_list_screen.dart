import 'dart:developer' as developer;
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
// import 'package:flutter_svg/flutter_svg.dart';

class ImageFolderScreen extends StatefulWidget {
  ImageFolderScreen({Key? key}) : super(key: key);

  @override
  _ImageFolderScreenState createState() => _ImageFolderScreenState();
}

class _ImageFolderScreenState extends State<ImageFolderScreen> {
  Future<List<FolderInfo>>? _folderListFuture;

  @override
  void initState() {
    super.initState();
    _folderListFuture = listFolders();
  }

  Future<void> requestStoragePermission() async {
    if (Platform.isAndroid) {
      var status = await Permission.storage.status;
      if (!status.isGranted) {
        if (await Permission.manageExternalStorage.request().isGranted) {
          developer.log('Manage external storage permission granted');
        } else {
          developer.log('Permission denied, opening app settings');
          openAppSettings();
        }
      } else {
        developer.log('Storage permission granted');
      }
    }
  }

  Future<List<FolderInfo>> listFolders() async {
    await requestStoragePermission();
    final List<FolderInfo> folderInfoList = [];
    final directories = await getStorageDirectories();
    developer.log('Directories to scan: ${directories.map((d) => d.path).toList()}');
    for (var directory in directories) {
      await scanDirectory(directory, folderInfoList);
    }
    folderInfoList.sort((a, b) => b.totalSize.compareTo(a.totalSize));
    return folderInfoList.take(6).toList();
  }

  Future<List<Directory>> getStorageDirectories() async {
    final List<Directory> directories = [];
    final primaryStorage = await getExternalStorageDirectory();
    if (primaryStorage != null) {
      directories.add(primaryStorage);
    }
    final List<Directory> commonDirs = [
      Directory('/storage/emulated/0/Pictures'),
      Directory('/storage/emulated/0/Downloads'),
      Directory('/storage/emulated/0/DCIM'),
      Directory('/storage/emulated/0/Documents')
    ];
    directories.addAll(commonDirs);
    return directories;
  }

  Future<void> scanDirectory(Directory directory, List<FolderInfo> folderInfoList) async {
    final List<String> imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
    try {
      await for (var entity in directory.list(recursive: true, followLinks: false)) {
        if (entity is File) {
          final extension = entity.path.split('.').last.toLowerCase();
          if (imageExtensions.contains(extension)) {
            final folderPath = entity.parent.path;
            final folderInfo = folderInfoList.firstWhere(
                  (folder) => folder.folderPath == folderPath,
              orElse: () {
                final newFolder = FolderInfo(folderPath: folderPath, imageCount: 0, totalSize: 0);
                folderInfoList.add(newFolder);
                return newFolder;
              },
            );
            folderInfo.imageCount += 1;
            folderInfo.totalSize += await entity.length();
          }
        }
      }
    } catch (e) {
      developer.log('Error scanning directory: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Image Folders'),
      ),
      body: FutureBuilder<List<FolderInfo>>(
        future: _folderListFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(
              child: CircularProgressIndicator(),
            );
          } else if (snapshot.hasError) {
            developer.log('Error: ${snapshot.error}');
            return Center(child: Text('Error: ${snapshot.error}'));
          } else if (snapshot.hasData) {
            final data = snapshot.data!;
            return GridView.builder(
              padding: const EdgeInsets.all(16.0),
              itemCount: data.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 2,
                childAspectRatio: 1,
                crossAxisSpacing: 16.0,
                mainAxisSpacing: 16.0,
              ),
              itemBuilder: (context, index) {
                final folder = data[index];
                return FolderCard(folder: folder);
              },
            );
          } else {
            return const Center(child: Text('No image folders found.'));
          }
        },
      ),
    );
  }
}

class FolderCard extends StatelessWidget {
  final FolderInfo folder;

  const FolderCard({Key? key, required this.folder}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4.0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12.0),
      ),
      child: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset('assets/folder.png',width: 64.0,height: 64.0,),
            // SvgPicture.asset(
            //   'assets/folder.svg',
            //   width: 64.0,
            //   height: 64.0,
            //   color: Colors.deepPurple,
            // ),
            const SizedBox(height: 16.0),
            Text(
              folder.folderPath.split('/').last,
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8.0),
            Text(
              '${folder.imageCount} items',
              style: const TextStyle(fontSize: 14.0, color: Colors.grey),
            ),
          ],
        ),
      ),
    );
  }
}

class FolderInfo {
  final String folderPath;
  int imageCount;
  int totalSize;

  FolderInfo({
    required this.folderPath,
    required this.imageCount,
    required this.totalSize,
  });
}