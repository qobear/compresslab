import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/settings_model.dart';

class SettingsProvider with ChangeNotifier {
  SettingsModel _settings = SettingsModel();
  bool _isWidthHeightEnabled = false;

  SettingsModel get settings => _settings;
  bool get isWidthHeightEnabled => _isWidthHeightEnabled;

  SettingsProvider() {
    _loadSettings();
  }

  void updateCompressionLevel(double level) {
    _settings.compressionLevel = level;
    _saveSettings();
    notifyListeners();
  }

  void updateWidth(int? width) {
    _settings.width = width;
    _saveSettings();
    notifyListeners();
  }

  void updateHeight(int? height) {
    _settings.height = height;
    _saveSettings();
    notifyListeners();
  }

  void toggleWidthHeightEnabled(bool isEnabled) {
    _isWidthHeightEnabled = isEnabled;
    _saveSettings();
    notifyListeners();
  }

  Future<void> _loadSettings() async {
    final prefs = await SharedPreferences.getInstance();
    _settings = SettingsModel(
      compressionLevel: prefs.getDouble('compressionLevel') ?? 80.0,
      width: prefs.getInt('width'),
      height: prefs.getInt('height'),
    );
    _isWidthHeightEnabled = prefs.getBool('isWidthHeightEnabled') ?? false;
    notifyListeners();
  }

  Future<void> _saveSettings() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setDouble('compressionLevel', _settings.compressionLevel);
    if (_settings.width != null) {
      prefs.setInt('width', _settings.width!);
    } else {
      prefs.remove('width');
    }
    if (_settings.height != null) {
      prefs.setInt('height', _settings.height!);
    } else {
      prefs.remove('height');
    }
    prefs.setBool('isWidthHeightEnabled', _isWidthHeightEnabled);
  }
}
