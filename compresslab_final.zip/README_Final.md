CompressLab Project - Final Modern UI Version siap build via Codemagic atau Flutter Local

- UI Modern
- Dark Mode
- Slider Preview
- Permission aman Play Store
- License integrasi tetap terjaga