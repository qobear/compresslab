import 'package:flutter/material.dart';
import 'package:hexagon/hexagon.dart';




class HexaGon extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.lightBlue.shade50,
      appBar: AppBar(
        title: Text('FOTORUS'),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Text(
                'FOTORUS',
                style: TextStyle(
                  fontSize: 32,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 2,
                ),
              ),
              SizedBox(height: 20),
              Expanded(
                child: GridView.count(
                  crossAxisCount: 2,
                  crossAxisSpacing: 16,
                  mainAxisSpacing: 16,
                  children: [
                    HexagonMenuItem(
                      icon: Icons.edit,
                      label: 'Pro Edit',
                      onTap: () => _navigateTo(context, 'Pro Edit'),
                    ),
                    HexagonMenuItem(
                      icon: Icons.collections,
                      label: 'Collage',
                      onTap: () => _navigateTo(context, 'Collage'),
                    ),
                    HexagonMenuItem(
                      icon: Icons.camera_alt,
                      label: 'Camera',
                      onTap: () => _navigateTo(context, 'Camera'),
                    ),
                    HexagonMenuItem(
                      icon: Icons.palette,
                      label: 'PaintLab',
                      onTap: () => _navigateTo(context, 'PaintLab'),
                    ),
                    HexagonMenuItem(
                      icon: Icons.photo_library,
                      label: 'Library',
                      onTap: () => _navigateTo(context, 'Library'),
                    ),
                    HexagonMenuItem(
                      icon: Icons.face,
                      label: 'Beauty',
                      onTap: () => _navigateTo(context, 'Beauty'),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _navigateTo(BuildContext context, String page) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text('Navigating to $page'),
    ));
  }
}

class HexagonMenuItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;

  HexagonMenuItem({required this.icon, required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          HexagonWidget.flat(
            width: 100,
            color: Colors.white,
            elevation: 4,
            child: Icon(
              icon,
              size: 50,
              color: Colors.blue,
            ),
          ),
          SizedBox(height: 8),
          Text(
            label,
            style: TextStyle(fontSize: 16, fontWeight: FontWeight.w500),
          ),
        ],
      ),
    );
  }
}