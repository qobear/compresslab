import 'dart:io';

import 'package:compresslab/helper/image_provider.dart';
import 'package:compresslab/screens/preview_image.dart';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart';
import 'package:lottie/lottie.dart';
import 'package:provider/provider.dart';
import 'package:simple_animated_button/elevated_layer_button.dart';

import '../helper/helperku.dart';
import '../helper/loadingku.dart';
import '../main.dart';

class CompressionScreen extends StatelessWidget {
  const CompressionScreen({Key? key}) : super(key: key);



  @override
  Widget build(BuildContext context) {
    final imageProvider = Provider.of<CustomeImageProvider>(context);
    final screenWidth = MediaQuery.of(context).size.width;

    void showImagePreview(
        BuildContext context, File imageFile, File? compressedFile) {
      showDialog(
          context: context,
          builder: (_) => ImagePreview(
              imageFile: imageFile, compressedFile: compressedFile));
    }

    bool hasCompressedImages =
        imageProvider.images.any((image) => image.compressedImage != null);
    double compressionPercentage = imageProvider.totalCompressedSize > 0
        ? ((imageProvider.totalOriginalSize -
                    imageProvider.totalCompressedSize) /
                imageProvider.totalOriginalSize) *
            100
        : 0;

    return Scaffold(
      appBar: AppBar(
        // title: const Text('Image Compression'),
      ),
      body: SingleChildScrollView(
        child: SizedBox(
          height: MediaQuery.of(context).size.height -
              MediaQuery.of(context).padding.top,
          child: Column(
            children: [
              ElevatedLayerButton(
                onClick: () async {
                  await requestStoragePermission();
                  // final log = Logger('Logging');
                  // log.info('My Logging test');
                  imageProvider.pickFolderAndLoadImages(); },
                buttonHeight: 60,
                buttonWidth: 270,
                animationDuration: const Duration(milliseconds: 200),
                animationCurve: Curves.ease,
                topDecoration: BoxDecoration(
                    color: Colors.orange,
                    border: Border.all(),
                    borderRadius: BorderRadius.all(Radius.circular(20))),
                topLayerChild: Text("Select Folder and Pick Images",style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),),
                baseDecoration: BoxDecoration(
                    color: Theme.of(context).colorScheme.primary,
                    border: Border.all(),
                    borderRadius: BorderRadius.all(Radius.circular(20))),
              ),
              // if (hasCompressedImages)
              //   Padding(
              //     padding: const EdgeInsets.all(16.0),
              //     child: Column(
              //       crossAxisAlignment: CrossAxisAlignment.start,
              //       children: [
              //         Text(
              //             'Total Original Size: ${(imageProvider.totalOriginalSize / (1024 * 1024)).toStringAsFixed(2)} MB'),
              //         Text(
              //             'Total Compressed Size: ${(imageProvider.totalCompressedSize / (1024 * 1024)).toStringAsFixed(2)} MB'),
              //         Text(
              //             'Optimasi hasil Compress: ${compressionPercentage.toStringAsFixed(2)}%'),
              //       ],
              //     ),
              //   ),
              SizedBox(height: 10),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  _buildStatistic('Original Size:', '${(imageProvider.totalOriginalSize / (1024 * 1024)).toStringAsFixed(2)} MB'),
                  _buildStatistic('Compressed Size:', '${(imageProvider.totalCompressedSize / (1024 * 1024)).toStringAsFixed(2)} MB'),
                  _buildStatistic('Optimization', '${compressionPercentage.toStringAsFixed(2)}%'),
                ],
              ),
              if (imageProvider.hasSelectedImages)
                ElevatedButton(
                  style: ButtonStyle(backgroundColor: MaterialStateColor.resolveWith((states) => Colors.orange)),
                  onPressed: () => imageProvider.compressImages(),
                  child:  Text('Compress ${imageProvider.images.length} Images ',style: TextStyle(color: Colors.black),),
                ),
              if (hasCompressedImages)
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    ElevatedButton(
                      style:  const ButtonStyle(
                        backgroundColor: MaterialStatePropertyAll<Color>(Colors.orange),
                      ),
                      onPressed: () async {
                        var status = await  requestPermissions();

                        bool confirmed = await showConfirmationDialog(
                          context,
                          'Confirm Keep Originals',
                          'Do you want to keep the original images and save the compressed images to a specific folder?',
                        );
                        if (confirmed) {
                          showLoadingDialog(
                              context, 'Saving Original Images...');
                          // await imageProvider.keepOriginalImages();
                          String? folderPath =
                              await imageProvider.keepOriginalImages();

                          hideLoadingDialog(context);
                          showCompletionDialog(
                              context,
                              'Original images kept and compressed images saved.',
                              folderPath);
                        }
                      },
                      child: const Text('Keep Originals'),
                    ),
                    ElevatedButton(
                      style:  const ButtonStyle(
                        backgroundColor: MaterialStatePropertyAll<Color>(Colors.orange),
                      ),
                      onPressed: () async {

                        // await imageProvider
                        //     .keepCompressedImages(replaceOriginal: true);
                        // await Permission.storage.request();
                        WidgetsFlutterBinding.ensureInitialized();
                       // var status =  await requestPermissions();
                        bool confirmed = await showConfirmationDialog(
                          context,
                          'Confirm save Compressed and replace Origin images',
                          'Do you want to save Compressed images and replace origin images?',
                        );
                        if (confirmed) {
                          showLoadingDialog(
                              context, 'Save Compressed & replace...');
                          // await imageProvider.keepCompressedImages(replaceOriginal: false);
                          String? folderPath = await imageProvider
                              .keepCompressedImages(replaceOriginal: true);
                          hideLoadingDialog(context);
                          showCompletionDialog(
                              context, 'Compressed images saved.', folderPath);
                        }
                      },
                      child: const Text('Keep Compressed'),
                    ),
                  ],
                ),
              Center(
                child: Text('Preview hanya tampil 50 list untuk optimasi app'),
              ),
              Expanded(
                child: imageProvider.hasSelectedImages
                    ?
                    // ListView.builder(
                    //         itemCount: imageProvider.images.length,
                    //         itemBuilder: (context, index) {
                    //           final imageData = imageProvider.images[index];
                    //           return Padding(
                    //             padding: const EdgeInsets.all(8.0),
                    //             child: Card(
                    //               shape: RoundedRectangleBorder(
                    //                 borderRadius: BorderRadius.circular(15),
                    //               ),
                    //               elevation: 5,
                    //               child: Column(
                    //                 mainAxisAlignment: MainAxisAlignment.spaceAround,
                    //                 crossAxisAlignment: CrossAxisAlignment.center,
                    //                 children: [
                    //                   const SizedBox(width: 20),
                    //                   Row(
                    //                     children: [
                    //                       Expanded(
                    //                         child: Column(
                    //                           children: [
                    //                             ClipRRect(
                    //                               borderRadius:
                    //                                   BorderRadius.circular(8),
                    //                               child: Image.file(
                    //                                 imageData.originalImage,
                    //                                 width: screenWidth * 0.4,
                    //                                 height: screenWidth * 0.4,
                    //                                 fit: BoxFit.cover,
                    //                               ),
                    //                             ),
                    //                             Text(
                    //                                 'Size: ${imageData.originalSize.toStringAsFixed(2)} MB'),
                    //                           ],
                    //                         ),
                    //                       ),
                    //                     ],
                    //                   ),
                    //                 ],
                    //               ),
                    //             ),
                    //           );
                    //         },
                    //       )
                    ListView.builder(
                        itemCount: imageProvider.images.length > 50 ? 50:imageProvider.images.length,
                        itemBuilder: (context, index) {
                          final imageData = imageProvider.images[index];
                          return Padding(
                            padding: const EdgeInsets.all(8.0),
                            child: Card(
                              margin: EdgeInsets.all(0),
                              color: const Color(0xFFFCEFEF),
                              // color: Theme.of(context).colorScheme.primary,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(15)),
                              elevation: 5,
                              child:
                              Column(
                                // mainAxisAlignment:
                                //     MainAxisAlignment.spaceAround,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  // const SizedBox(width: 20),
                                  // if (!imageData.isCompressing &&
                                  //     imageData.compressedSize != null)
                                  //   Padding(
                                  //     padding: const EdgeInsets.only(right: 8),
                                  //     child:
                                  //         Text(
                                  //       'Reduction: ${imageData.compressionPercentage.toStringAsFixed(2)}%',
                                  //       style: const TextStyle(
                                  //           fontSize: 16,
                                  //           fontWeight: FontWeight.w500,
                                  //           color: Colors.green),
                                  //     ),
                                  //   ),
                                  Padding(
                                    padding: const EdgeInsets.all(0),
                                    child: Row(
                                      children: [
                                        Expanded(
                                          child:
                                          Column(
                                            mainAxisAlignment: MainAxisAlignment.spaceAround,
                                            children: [
                                              GestureDetector(
                                                onTap: () => showImagePreview(
                                                    context,
                                                    imageData.originalImage,
                                                    imageData.compressedImage),
                                                child: Hero(
                                                  tag: imageData
                                                      .originalImage.path,
                                                  child: ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(8),
                                                    child: Image.file(
                                                      imageData.originalImage,
                                                      width: screenWidth * 0.4,
                                                      height: screenWidth * 0.4,
                                                      fit: BoxFit.cover,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              Text(
                                                  'Size: ${formatBytesToMB(imageData.originalSize)} Mb'),
                                            ],
                                          ),
                                        ),
                                        const SizedBox(width: 20),
                                        Column(
                                          children: [
                                            const SizedBox(width: 20),
                                            if (imageData.isCompressing)
                                              Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: Lottie.asset(
                                                    "assets/ai_loading.json",
                                                    width: 100,
                                                    height: 100),
                                                // const CircularProgressIndicator(),
                                              ),
                                            if (imageData.compressedImage !=
                                                    null &&
                                                !imageData.isCompressing)
                                              GestureDetector(
                                                onTap: () => showImagePreview(
                                                    context,
                                                    imageData.originalImage,
                                                    imageData.compressedImage!),
                                                child: Hero(
                                                  tag: imageData
                                                      .compressedImage!.path,
                                                  child: ClipRRect(
                                                    borderRadius:
                                                        BorderRadius.circular(8),
                                                    child: Image.file(
                                                      imageData.compressedImage!,
                                                      width: screenWidth * 0.4,
                                                      height: screenWidth * 0.4,
                                                      fit: BoxFit.cover,
                                                    ),
                                                  ),
                                                ),
                                              ),
                                            // else
                                              // const Text('No compressed image'),
                                              // Text(
                                              //   'Original Size: ${formatBytesToMB(imageData.originalSize)} MB',
                                              //   style: const TextStyle(
                                              //       fontSize: 16,
                                              //       fontWeight: FontWeight.w500),
                                              // ),
                                            if (imageData.compressedSize != null)
                                              Text(
                                                  'Size: ${imageData.compressedSize != null ? formatBytesToMB(imageData.compressedSize!) : '0'} MB')
                                            // Text(
                                            //   'Size: ${formatBytesToMB(imageData.compressedSize!)} MB',
                                            //   style: const TextStyle(
                                            //       fontSize: 16,
                                            //       fontWeight: FontWeight.w500),
                                            // ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      )
                    : const Center(
                        child: Text('No images selected'),
                      ),
              ),

            ],
          ),
        ),
      ),
    );
  }
}

Widget _buildStatistic(String title, String value) {
  return Column(
    children: [
      Text(
        value,
        style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
      ),
      SizedBox(height: 4),
      Text(title),
    ],
  );
}
