import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:io';




class ImagePickerScreen extends StatelessWidget {
  final ValueNotifier<File?> _imageNotifier = ValueNotifier<File?>(null);
  final ValueNotifier<double> _widthNotifier = ValueNotifier<double>(300);
  final ValueNotifier<double> _heightNotifier = ValueNotifier<double>(300);

  Future<void> _pickImage() async {
    final pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);

    if (pickedFile != null) {
      _imageNotifier.value = File(pickedFile.path);
    }
  }

  Future<void> _resizeAndSaveImage() async {
    if (_imageNotifier.value == null) return;

    final customDirectory = await FilePicker.platform.getDirectoryPath();
    if (customDirectory == null) return;

    final path = '$customDirectory/resized_image.png';

    // Read image
    final img.Image image = img.decodeImage(_imageNotifier.value!.readAsBytesSync())!;

    // Resize image
    final img.Image resized = img.copyResize(
      image,
      width: _widthNotifier.value.toInt(),
      height: _heightNotifier.value.toInt(),
    );

    // Save resized image to custom directory
    final resizedFile = File(path)..writeAsBytesSync(img.encodePng(resized));
    _imageNotifier.value = resizedFile;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Image Resizer'),
      ),
      body: SingleChildScrollView(
        child: Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              ValueListenableBuilder<File?>(
                valueListenable: _imageNotifier,
                builder: (context, image, child) {
                  return image == null
                      ? Text('No image selected.')
                      : Image.file(image);
                },
              ),
              SizedBox(height: 20),
              ValueListenableBuilder<File?>(
                valueListenable: _imageNotifier,
                builder: (context, image, child) {
                  return image != null
                      ? Column(
                    children: [
                      ValueListenableBuilder<double>(
                        valueListenable: _widthNotifier,
                        builder: (context, width, child) {
                          return Column(
                            children: [
                              Text('Width: ${width.toInt()}'),
                              Slider(
                                value: width,
                                min: 100,
                                max: 1000,
                                divisions: 900,
                                thumbColor: Colors.black,
                                activeColor: Colors.black45,
                                label: width.round().toString(),
                                onChanged: (double value) {
                                  _widthNotifier.value = value;
                                },
                              ),
                            ],
                          );
                        },
                      ),
                      ValueListenableBuilder<double>(
                        valueListenable: _heightNotifier,
                        builder: (context, height, child) {
                          return Column(
                            children: [
                              Text('Height: ${height.toInt()}'),
                              Slider(
                                value: height,
                                min: 100,
                                max: 1000,
                                divisions: 900,
                                thumbColor: Colors.black,
                                activeColor: Colors.black45,
                                label: height.round().toString(),
                                onChanged: (double value) {
                                  _heightNotifier.value = value;
                                },
                              ),
                            ],
                          );
                        },
                      ),
                      ElevatedButton(
                        style:  const ButtonStyle(
                          backgroundColor: MaterialStatePropertyAll<Color>(Colors.orange),
                        ),
                        onPressed: _resizeAndSaveImage,
                        child: Text('Resize and Save Image'),
                      ),
                    ],
                  )
                      : Container();
                },
              ),
              SizedBox(height: 20),
              FilledButton(
                style:  const ButtonStyle(
                  backgroundColor: MaterialStatePropertyAll<Color>(Colors.orange),
                ),
                onPressed: _pickImage,
                child: Text('Pick Image'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}