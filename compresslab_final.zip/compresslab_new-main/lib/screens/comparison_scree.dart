import 'package:compresslab/helper/image_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class CompressionResultScreen extends StatelessWidget {
  const CompressionResultScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final imageProvider = Provider.of<CustomeImageProvider>(context);
    final screenWidth = MediaQuery.of(context).size.width;

    double compressionPercentage = imageProvider.totalOriginalSize > 0
        ? ((imageProvider.totalOriginalSize -
                    imageProvider.totalCompressedSize) /
                imageProvider.totalOriginalSize) *
            100
        : 0;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Compression Results'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                    'Total Original Size: ${(imageProvider.totalOriginalSize / (1024 * 1024)).toStringAsFixed(2)} MB'),
                Text(
                    'Total Compressed Size: ${(imageProvider.totalCompressedSize / (1024 * 1024)).toStringAsFixed(2)} MB'),
                Text(
                    'Compression Percentage: ${compressionPercentage.toStringAsFixed(2)}%'),
              ],
            ),
          ),
          Expanded(
            child: ListView.builder(
              itemCount: imageProvider.images.length,
              itemBuilder: (context, index) {
                final imageData = imageProvider.images[index];
                return Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Card(
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15),
                    ),
                    elevation: 5,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        const SizedBox(width: 20),
                        Row(
                          children: [
                            Expanded(
                              child: Column(
                                children: [
                                  ClipRRect(
                                    borderRadius: BorderRadius.circular(8),
                                    child: Image.file(
                                      imageData.originalImage,
                                      width: screenWidth * 0.4,
                                      height: screenWidth * 0.4,
                                      fit: BoxFit.cover,
                                    ),
                                  ),
                                  Text(
                                      'Size: ${imageData.imageSizeInMB.toStringAsFixed(2)} MB'),
                                ],
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
