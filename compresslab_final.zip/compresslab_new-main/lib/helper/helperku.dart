import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:logging/logging.dart';
import 'package:path/path.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:flutter/services.dart' show rootBundle;


final log = Logger('Logging');
DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();

Future<void> copyFile(String sourcePath, String destinationPath) async {
  try {
    // Request storage permissions
    if (await Permission.storage.request().isGranted) {
      File sourceFile = File(sourcePath);
      Directory destinationDir = Directory(dirname(destinationPath));

      // Check if source file exists
      if (await sourceFile.exists()) {
        // Ensure destination directory exists
        if (!await destinationDir.exists()) {
          await destinationDir.create(recursive: true);
        }

        // Copy the file
        await sourceFile.copy(destinationPath);
        print('File copied successfully.');
      } else {
        print('Source file does not exist.');
      }
    } else {
      print('Storage permission denied.');
    }
  } catch (e) {
    print('Error during file operation: $e');
  }
}

Future<void> requestPermissions() async {
  var status = await Permission.photos.request();
  // bool permissionStatus;
  // final deviceInfo =await DeviceInfoPlugin().androidInfo;
  //
  // if(deviceInfo.version.sdkInt>32){
  //   permissionStatus = await Permission.photos.request().isGranted;
  // }else{
  //   permissionStatus = await Permission.storage.request().isGranted;
  //
  // }

  if (status.isGranted) {
    // var status2 = await Permission.storage.request();
    // print('Status izin photos/storage: $status2');
    // if (status2.isGranted) {
    //  print('Status izin penyimpanan: $status2');
    // }
    // if (!status2.isGranted) {
    //   throw Exception('Storage permission not granted');
    // }
    // PermissionStatus status = await Permission.storage.status;
    // if (!status.isGranted) {
    //   status = await Permission.storage.request();
    // }
    //
    // if (status.isGranted) {
    //   // Permission granted
    //   print('Storage permission granted');
    // } else if (status.isDenied) {
    //   // Permission denied
    //   print('Storage permission denied');
    // } else if (status.isPermanentlyDenied) {
    //   // Permission permanently denied, navigate to settings
    //   print('Storage permission permanently denied');
    //   openAppSettings();
    // }

    // var status = await Permission.storage.status;
    // if (!status2.isGranted) {
    //   await Permission.storage.request();
    //   throw Exception('Storage permission not granted');
    // }

  }

}


Future<void> requestStoragePermission() async {
  AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
  PermissionStatus status = await Permission.manageExternalStorage.status;
  // AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
  // PermissionStatus status = await Permission.storage.request();
  if (!status.isGranted) {
    status = await Permission.manageExternalStorage.request();
    // status = await Permission.storage.request();
    log.info('manageExternalStorage permission denied on ${androidInfo.data}');
  }

  if (status.isGranted) {
    // Permission granted
    print('Storage permission granted');
    log.info('Storage permission granted on ${androidInfo.data}');
  } else if (status.isDenied) {
    // Permission denied
    log.info('Storage permission denied on ${androidInfo.data}');
    print('Storage permission denied');
  } else if (status.isPermanentlyDenied) {
    // Permission permanently denied, navigate to settings
    print('Storage permission permanently denied');
    log.info('Storage permission permanently denied on ${androidInfo.data}');
    openAppSettings();
  }
}

Future<String> getReleaseVersion() async {
  final contents = await rootBundle.loadString('pubspec.yaml');
  final lines = contents.split('\n');

  for (var line in lines) {
    if (line.startsWith('version:')) {
      final version = line.split(':')[1].trim();
      return version;
    }
  }
  return 'Error: Version not found';
}