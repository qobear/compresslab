import 'package:compresslab/helper/image_provider.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

class LogHistoryScreen extends StatelessWidget {
  const LogHistoryScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final imageProvider = Provider.of<CustomeImageProvider>(context);
    final logHistory = imageProvider.logHistory;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Log History'),
      ),
      body: ListView.builder(
        itemCount: logHistory.keys.length,
        itemBuilder: (context, index) {
          String directory = logHistory.keys.elementAt(index);
          List<Map<String, String>> logs = logHistory[directory]!;
          int fileCount = logs.length;

          return ExpansionTile(
            title: Text('Directory: $directory'),
            subtitle: Text('Total Compressed Files: $fileCount'),
            children: logs.map((log) {
              return ListTile(
                title: Text('Original: ${log['original']}'),
                subtitle: Text('Compressed: ${log['compressed']}'),
              );
            }).toList(),
          );
        },
      ),
    );
  }
}
