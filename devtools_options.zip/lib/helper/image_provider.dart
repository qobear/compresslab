import 'dart:convert';
import 'dart:io';

import 'package:android_content_provider/android_content_provider.dart';
import 'package:disk_space_plus/disk_space_plus.dart';
import 'settings_provider.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'helperku.dart';
import 'loadingku.dart';
import 'package:android_intent_plus/android_intent.dart';

const platform = MethodChannel('com.example.file/delete');

const MethodChannel _channel = MethodChannel('plugins.flutter.io/path_provider');

class ImageData {
  final File originalImage;
  final File? compressedImage;
  final int originalSize;
  final int? compressedSize;
  bool isCompressing;

  ImageData({
    required this.originalImage,
    required this.originalSize,
    this.compressedImage,
    this.compressedSize,
    this.isCompressing = false,
  });

  double get imageSizeInMB => originalSize / (1024 * 1024);

  double get compressionPercentage {
    if (compressedSize == null || originalSize == 0) return 0;
    return ((originalSize - compressedSize!) / originalSize) * 100;
  }
}

class CustomeImageProvider with ChangeNotifier {
  List<ImageData> _images = [];
  Map<String, List<Map<String, String>>> _logHistory = {};
  bool _hasSelectedImages = false;
  bool _isLoading = false;
  double _progress = 0.0;
  double? _usedSpace;
  double? _freeSpace;
  double _totalOriginalSize = 0;
  double _totalCompressedSize = 0;
  final SettingsProvider settingsProvider;

  CustomeImageProvider(this.settingsProvider) {
    _loadLogHistory();
  }

  List<ImageData> get images => _images;
  Map<String, List<Map<String, String>>> get logHistory => _logHistory;
  bool get hasSelectedImages => _hasSelectedImages;
  bool get isLoading => _isLoading;
  double get progress => _progress;
  double? get usedSpace => _usedSpace;
  double? get freeSpace => _freeSpace;
  double get totalOriginalSize => _totalOriginalSize;
  double get totalCompressedSize => _totalCompressedSize;


  Future<void> fetchDiskSpace() async {
    _usedSpace = await DiskSpacePlus.getTotalDiskSpace;
    _freeSpace = await DiskSpacePlus.getFreeDiskSpace;
    notifyListeners();
  }

  Future<void> pickImages() async {
    final result = await FilePicker.platform.pickFiles(
        allowMultiple: true,
        type: FileType.custom,
        allowedExtensions: ['jpg', 'jpeg', 'png']);

    if (result != null) {
      _images = result.paths.map((path) {
        final file = File(path!);
        return ImageData(
          originalImage: file,
          originalSize: file.lengthSync(),
        );
      }).toList();

      _hasSelectedImages = _images.isNotEmpty;
      notifyListeners();
      // await compressImages();
    }
  }

  Future<void> compressImages() async {
    final tempDir = await getTemporaryDirectory();
    _totalCompressedSize = 0;
    for (var i = 0; i < _images.length; i++) {
      final image = _images[i];
      image.isCompressing = true;
      notifyListeners();
      // Introduce a delay for demonstration purposes
      await Future.delayed(const Duration(milliseconds: 30));
      final compressedFilePath = path.join(tempDir.path,
          '${path.basenameWithoutExtension(image.originalImage.path)}_compressed.jpg');
      print('image source  ${image.originalImage.absolute.path}');
      final compressedFile = await FlutterImageCompress.compressAndGetFile(
        image.originalImage.absolute.path,
        // '${image.originalImage.path}_compressed.jpg',
        compressedFilePath,
        // quality: 80,
        quality: settingsProvider.settings.compressionLevel.toInt(),
        minWidth: settingsProvider.isWidthHeightEnabled
            ? settingsProvider.settings.width!.toInt()
            : 1080,
        minHeight: settingsProvider.isWidthHeightEnabled
            ? settingsProvider.settings.height!.toInt()
            : 1920,
      );

      if (compressedFile != null) {
        var ncompress = File(compressedFile.path);
        _images[i] = ImageData(
          originalImage: image.originalImage,
          originalSize: image.originalSize,
          compressedImage: ncompress,
          compressedSize: ncompress.lengthSync(),
          isCompressing: false,
        );
        _totalCompressedSize += ncompress.lengthSync();

        // Log the compression history
        String directory = Directory(image.originalImage.path).parent.path;
        _logHistory[directory] = _logHistory[directory] ?? [];
        _logHistory[directory]!.add({
          'original': image.originalImage.path,
          'compressed': compressedFile.path,
        });
        _logCompressedFile(ncompress);
      } else {
        _images[i].isCompressing = false;
      }

      notifyListeners();
    }

    _isLoading = false;
    notifyListeners();
    await _saveLogHistory();
  }

  Future<String?> keepOriginalImages() async {
    String? selectedDirectory = await FilePicker.platform.getDirectoryPath();
    if (selectedDirectory != null) {
      _progress = 0.0;
      notifyListeners();
      for (var i = 0; i < _images.length; i++) {
        final image = _images[i];
        if (image.compressedImage != null) {
          final newPath = path.join(
              selectedDirectory, path.basename(image.compressedImage!.path));
          await image.compressedImage!.copy(newPath);
        }
        _progress = (i + 1) / _images.length;
        notifyListeners();
      }
      _progress = 1.0;
      notifyListeners();
      return selectedDirectory;
    }
    return null;
  }

  Future<String?> keepCompressedImages({bool replaceOriginal = false}) async {
    _progress = 0.0;
    notifyListeners();
    String? selectedDirectory;

    if (!replaceOriginal) {
      selectedDirectory = await FilePicker.platform.getDirectoryPath();
    }
    for (var i = 0; i < _images.length; i++) {
      final image = _images[i];
      if (replaceOriginal) {
        if (image.compressedImage != null) {
          print('delete image ${image.originalImage.path}');
          print('sourcenya image ${image.originalImage.absolute.path}');
          final file = File(image.originalImage.path);
          if (file.existsSync()) {
            print('file ada : ${file}');
          } else {
            print('file kosong : ${file}');
          }

          // Use MediaStore API to replace the original file
          await replaceOriginalFileWithCompressed(image.originalImage, image.compressedImage!);
            // await copyFileToExternalStorage( image.compressedImage!.path, image.originalImage.);


          // deleteFile(image.originalImage.path);
          // await image.compressedImage!.rename(image.originalImage.path);
        }
      } else {
        // String? selectedDirectory = await FilePicker.platform.getDirectoryPath();

        if (selectedDirectory != null) {
          if (image.compressedImage != null) {
            final newPath = path.join(
                selectedDirectory, path.basename(image.compressedImage!.path));
            await image.compressedImage!.copy(newPath);
          }
        }
      }
      _progress = (i + 1) / _images.length;
      notifyListeners();
    }
    _progress = 1.0;
    notifyListeners();
    return replaceOriginal ? selectedDirectory : selectedDirectory;
  }

  Future<void> pickFolderAndLoadImages({String? folderPath}) async {
    try {
      await requestPermissions();
      // await requestStoragePermission();
      // await fetchDiskSpace();
      // String? selectedDirectory = await FilePicker.platform.getDirectoryPath();
      String? selectedDirectory = folderPath ?? await FilePicker.platform.getDirectoryPath();
      if (selectedDirectory != null) {
        Directory dir = Directory(selectedDirectory);
        List<File> imageFiles = [];
        int totalSize = 0;
        await for (var entity
            in dir.list(recursive: false, followLinks: false)) {
          if (entity is File && _isImageFile(entity.path)) {
            int fileSize = entity.lengthSync();
            imageFiles.add(entity);
            totalSize += fileSize;
            if (imageFiles.length >= 100) {
              break;
            }
          }
        }
        _images = imageFiles.map((file) {
          return ImageData(
            originalImage: file,
            originalSize: file.lengthSync(),
          );
        }).toList();
        _totalOriginalSize =
            _images.fold(0, (sum, item) => sum + item.originalSize);
        _hasSelectedImages = _images.isNotEmpty;
        notifyListeners();
      }
    } catch (e) {
      if (kDebugMode) {
        print(e);
      }
    }
  }

  void _logCompressedFile(File compressedFile) {
    print('Compressed File: ${compressedFile.path}');
  }

  void _logAllFiles() {
    for (var image in _images) {
      print('File: ${image.compressedImage?.path ?? image.originalImage.path}');
    }
  }

  bool _isImageFile(String path) {
    final extension = path.split('.').last.toLowerCase();
    return ['jpg', 'jpeg', 'png', 'webp'].contains(extension);
  }

  Future<void> _saveLogHistory() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('logHistory', json.encode(_logHistory));
  }

  Future<void> _loadLogHistory() async {
    final prefs = await SharedPreferences.getInstance();
    String? logHistoryString = prefs.getString('logHistory');
    if (logHistoryString != null) {
      _logHistory = Map<String, List<Map<String, String>>>.from(
        json.decode(logHistoryString).map(
              (key, value) => MapEntry(
                key,
                List<Map<String, String>>.from(
                    value.map((item) => Map<String, String>.from(item))),
              ),
            ),
      );
      notifyListeners();
    }
  }

  Future<void> deleteFile(String filePath) async {
    try {
      final bool result =
          await platform.invokeMethod('deleteFile', {'filePath': filePath});
      if (result) {
        print('File deleted successfully');
      } else {
        print('Failed to delete the file');
      }
    } on PlatformException catch (e) {
      print("Failed to delete file: '${e.message}'.");
    }
  }

  // Future<void> requestPermissions() async {
  //   var status = await Permission.storage.status;
  //   // if (!status.isGranted) {
  //   //   await Permission.storage.request();
  //   // }
  //   if (!status.isGranted) {
  //     // Request storage permission
  //     if (await Permission.storage.request().isGranted) {
  //       print("Storage permission granted");
  //     } else {
  //       print("Storage permission denied");
  //     }
  //   }
  // }

  Future<void> copyAndDeleteFile(
      String sourcePath, String destinationPath) async {
    await requestPermissions();
    final sourceFile = File(sourcePath);
    final destinationFile = File(destinationPath);

    try {
      // Ensure the destination directory exists
      if (!(await destinationFile.parent.exists())) {
        await destinationFile.parent.create(recursive: true);
      }

      // Copy the file to the new location
      await sourceFile.copy(destinationFile.path);

      // Delete the original file
      await sourceFile.delete();

      print('File copied and original file deleted successfully');
    } catch (e) {
      print('Error during file operation: $e');
    }
  }


  Future<void> _replaceOriginalFileWithCompressed(File originalFile, File compressedFile) async {
    try {
      final bytes = await compressedFile.readAsBytes();

      final fileUri = Uri.parse(originalFile.path);

      final mimeType = _getMimeType(originalFile.path);
      final mediaType = mimeType.split('/')[0];

      if (mediaType == 'image') {
        final intent = AndroidIntent(
          action: 'android.intent.action.MEDIA_SCANNER_SCAN_FILE',
          data: fileUri.toString(),
        );
        await intent.launch();

        final output = await File(originalFile.path).writeAsBytes(bytes);
        print('Replaced original file with compressed file: ${output.path}');
      } else {
        print('Unsupported media type: $mediaType');
      }
    } catch (e) {
      print('Failed to replace original file with compressed file: ${originalFile.path}, Error: $e');
    }
  }

  String _getMimeType(String filePath) {
    final extension = path.extension(filePath).toLowerCase();
    switch (extension) {
      case '.jpg':
      case '.jpeg':
        return 'image/jpeg';
      case '.png':
        return 'image/png';
      case '.webp':
        return 'image/webp';
      default:
        return 'application/octet-stream';
    }
  }


  // Future<void> copyFileToExternalStorage(String sourcePath, String destinationPath) async {
  //   try {
  //     final sourceFile = File(sourcePath);
  //     if (await sourceFile.exists()) {
  //       // Request storage permission
  //       var status = await Permission.storage.status;
  //       if (!status.isGranted) {
  //         status = await Permission.storage.request();
  //         if (!status.isGranted) {
  //           print('Storage permission denied.');
  //           return;
  //         }
  //       }
  //
  //       // Get external storage directory using path_provider
  //       final externalDir = await getExternalStorageDirectory();
  //       final picturesDir = Directory(path.join(externalDir!.path, 'Pictures'));
  //       final destinationFile = File(path.join(picturesDir.path, destinationPath));
  //
  //       // Ensure the destination directory exists
  //       if (!(await destinationFile.parent.exists())) {
  //         await destinationFile.parent.create(recursive: true);
  //       }
  //
  //       // Copy the file to the new location
  //       await sourceFile.copy(destinationFile.path);
  //       print('File copied successfully to external storage: ${destinationFile.path}');
  //
  //       // Delete the original file (optional)
  //       // await sourceFile.delete();
  //       // print('Original file deleted successfully.');
  //     } else {
  //       print('Source file does not exist.');
  //     }
  //   } catch (e) {
  //     print('Error during file operation: $e');
  //   }
  // }


  // Future<void> copyFileToExternalStorage(String sourcePath, String destinationPath) async {
  //   try {
  //     final sourceFile = File(sourcePath);
  //     await requestPermissions();
  //     if (await sourceFile.exists()) {
  //       // Get external storage directory
  //       final externalDir = await getExternalStorageDirectory();
  //       final destinationFile = File(join(externalDir!.path, destinationPath));
  //
  //       // Ensure the destination directory exists
  //       if (!(await destinationFile.parent.exists())) {
  //         await destinationFile.parent.create(recursive: true);
  //       }
  //
  //       // Copy the file to the new location
  //       await sourceFile.copy(destinationFile.path);
  //       print('File copied successfully to external storage.');
  //
  //       // Delete the original file
  //       await sourceFile.delete();
  //       print('Original file deleted successfully.');
  //     } else {
  //       print('Source file does not exist.');
  //     }
  //   } catch (e) {
  //     print('Error during file operation: $e');
  //   }
  // }





// void keepCompressedImages() {
//   _images = _images.map((image) {
//     return ImageData(
//       originalImage: image.compressedImage ?? image.originalImage,
//       originalSize: image.compressedSize ?? image.originalSize,
//     );
//   }).toList();
//   _logAllFiles();
//   notifyListeners();
// }

// Future<void> pickFolderAndLoadImages() async {
//   try {
//     await _requestPermissions();
//   } catch (e) {
//     if (kDebugMode) {
//       print(e);
//     }
//     return;
//   }

//   String? selectedDirectory = await FilePicker.platform.getDirectoryPath();
//   if (kDebugMode) {
//     print("folder selected  ${selectedDirectory}.");
//   }
//   // if (selectedDirectory != null) {
//   // Directory dir = Directory(selectedDirectory);
//   // List<File> imageFiles = [];

//   // await for (var entity in dir.list(recursive: false, followLinks: false)) {
//   //   print("entiti ${entity} \n");
//   //   if (entity is File && _isImageFile(entity.path)) {
//   //     imageFiles.add(entity);
//   //   }
//   // }
//   if (selectedDirectory == null) {
//     // User canceled the picker
//     return;
//   }

//   // Get the list of files in the directory
//   final directory = Directory(selectedDirectory);
//   // List<FileSystemEntity> files = directory.listSync();
//   List<FileSystemEntity> files = [];
//   await for (var file
//       in directory.list(recursive: false, followLinks: false)) {
//     files.add(file);
//   }

//   if (kDebugMode) {
//     print('Total files in directory: ${files.length}');
//     print('Files in directory: ${files.map((file) => file.path).join(', ')}');
//   }

//   // Filter image files (e.g., .jpg, .png)
//   List<File> imageFiles = files
//       .where((file) => file is File && _isImageFile(file.path))
//       .map((file) => file as File)
//       .toList();

//   if (kDebugMode) {
//     print(
//         "Filtered image files: ${imageFiles.map((file) => file.path).join(', ')}");
//     print("Loaded ${imageFiles.length} images.");
//   }
//   _images = imageFiles.map((file) {
//     return ImageData(
//       originalImage: file,
//       originalSize: file.lengthSync(),
//     );
//   }).toList();
//   _hasSelectedImages = _images.isNotEmpty;
//   notifyListeners();
//   // await compressImages();
//   // }
// }
}



Future<void> replaceOriginalFileWithCompressed(File originalFile, File compressedFile) async {
  try {
    final bytes = await compressedFile.readAsBytes();

    final fileUri = Uri.parse(originalFile.path);

    final mimeType = _getMimeType(originalFile.path);
    final mediaType = mimeType.split('/')[0];

    if (mediaType == 'image') {
      // Writing the compressed bytes to the original file path
      final output = await File(originalFile.path).writeAsBytes(bytes);
      print('Replaced original file with compressed file: ${output.path}');

      // Scan the file after writing
      await _scanFile(output.path);
    } else {
      print('Unsupported media type: $mediaType');
    }
  } catch (e) {
    print('Failed to replace original file with compressed file: ${originalFile.path}, Error: $e');
  }
}

Future<void> _scanFile(String path) async {
  try {
    await _channel.invokeMethod('scanFile', {'path': path});
  } catch (e) {
    print('Failed to scan file: $path, Error: $e');
  }
}

String _getMimeType(String path) {
  if (path.endsWith('.jpg') || path.endsWith('.jpeg')) {
    return 'image/jpeg';
  }else if (path.endsWith('.JPG')) {
    return 'image/jpeg';
  }else if (path.endsWith('.png')) {
    return 'image/png';
  } else if (path.endsWith('.gif')) {
    return 'image/gif';
  } else if (path.endsWith('.bmp')) {
    return 'image/bmp';
  } else if (path.endsWith('.webp')) {
    return 'image/webp';
  } else {
    return 'application/octet-stream';
  }
}

String formatBytesToMB(int bytes) {
  return bytesToMB(bytes).toStringAsFixed(2);
}

double bytesToMB(int bytes) {
  return bytes / 1024 / 1024;
}
