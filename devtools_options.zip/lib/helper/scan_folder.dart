import 'dart:developer' as developer;
import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart';

import '../models/folder_info.dart';

class FolderService {
  Future<void> requestStoragePermission() async {
    if (Platform.isAndroid) {
      var status = await Permission.storage.status;
      if (!status.isGranted) {
        if (await Permission.manageExternalStorage.request().isGranted) {
          developer.log('Manage external storage permission granted');
        } else {
          developer.log('Permission denied, opening app settings');
          openAppSettings();
        }
      } else {
        developer.log('Storage permission granted');
      }
    }
  }

  Future<List<FolderInfo>> listFolders() async {
    await requestStoragePermission();
    final List<FolderInfo> folderInfoList = [];
    final directories = await getStorageDirectories();
    developer.log('Directories to scan: ${directories.map((d) => d.path).toList()}');
    for (var directory in directories) {
      if (await directory.exists()) {
        await scanDirectory(directory, folderInfoList);
      } else {
        developer.log('Directory does not exist: ${directory.path}');
      }
    }
    folderInfoList.sort((a, b) => b.totalSize.compareTo(a.totalSize));
    return folderInfoList.take(6).toList();
  }

  Future<List<Directory>> getStorageDirectories() async {
    final List<Directory> directories = [];
    final primaryStorage = await getExternalStorageDirectory();
    if (primaryStorage != null) {
      directories.add(primaryStorage);
    }
    final List<Directory> commonDirs = [
      Directory('/storage/emulated/0/Pictures'),
      Directory('/storage/emulated/0/Download'),
      Directory('/storage/emulated/0/DCIM'),
      Directory('/storage/emulated/0/Documents')
    ];
    directories.addAll(commonDirs);
    return directories;
  }

  Future<void> scanDirectory(Directory directory, List<FolderInfo> folderInfoList) async {
    final List<String> imageExtensions = ['jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp'];
    try {
      await for (var entity in directory.list(recursive: true, followLinks: false)) {
        if (entity is File) {
          final extension = entity.path.split('.').last.toLowerCase();
          if (imageExtensions.contains(extension)) {
            final folderPath = entity.parent.path;
            final folderInfo = folderInfoList.firstWhere(
                  (folder) => folder!.folderPath == folderPath,
              orElse: () {
                final newFolder = FolderInfo(folderPath: folderPath, imageCount: 0, totalSize: 0);
                folderInfoList.add(newFolder);
                return newFolder;
              },
            );
            folderInfo.imageCount += 1;
            folderInfo.totalSize += await entity.length();
          }
        }
      }
    } catch (e) {
      developer.log('Error scanning directory: $e');
    }
  }
}