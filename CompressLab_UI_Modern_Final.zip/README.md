CompressLab Project - UI Modern Version
Siap build via Codemagic atau Flutter Local