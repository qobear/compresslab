import 'package:flutter/material.dart';

import '../models/folder_info.dart';

class FolderCard extends StatelessWidget {
  final FolderInfo folder;
  final VoidCallback onTap;

  const FolderCard({Key? key, required this.folder, required this.onTap}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Card(
        elevation: 4.0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12.0),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset('assets/folder.png',width: 64.0,height: 64.0,),
              const SizedBox(height: 16.0),
              Text(
                folder.folderPath.split('/').last,
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 16.0, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 8.0),
              Text(
                '${folder.imageCount} items',
                style: const TextStyle(fontSize: 14.0, color: Colors.grey),
              ),
            ],
          ),
        ),
      ),
    );
  }
}