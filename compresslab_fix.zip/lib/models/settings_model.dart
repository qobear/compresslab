class SettingsModel {
  double compressionLevel;
  int? width;
  int? height;

  SettingsModel({
    this.compressionLevel = 80.0,
    this.width,
    this.height,
  });
}
