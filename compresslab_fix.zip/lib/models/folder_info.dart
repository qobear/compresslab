// folder_info.dart

class FolderInfo {
  final String folderPath;
  int imageCount;
  int totalSize;

  FolderInfo({
    required this.folderPath,
    required this.imageCount,
    required this.totalSize,
  });
}