import 'dart:developer';
import 'dart:io';

import 'package:animated_notch_bottom_bar/animated_notch_bottom_bar/animated_notch_bottom_bar.dart';
import 'package:circular_seek_bar/circular_seek_bar.dart';
import 'package:compresslab/screens/folder_card.dart';
// import 'package:compresslab/screens/folder_list_screen.dart';
import 'package:compresslab/screens/hexagon_screen.dart';
import 'package:compresslab/screens/profile_screen.dart';
import 'package:compresslab/screens/resize_screen.dart';
import 'package:disk_space_plus/disk_space_plus.dart';
import 'package:compresslab/screens/compress_screen.dart';
import 'package:compresslab/screens/log_history_screen.dart';
import 'package:compresslab/screens/preview_image.dart';
import 'package:compresslab/screens/settings_screen.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:logging/logging.dart';
import 'package:lottie/lottie.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import 'package:provider/provider.dart';
import 'package:sentry_flutter/sentry_flutter.dart';
import 'package:sentry_logging/sentry_logging.dart';
import 'package:url_launcher/url_launcher.dart';

import 'helper/image_provider.dart';
import 'helper/license_provider.dart';
import 'helper/scan_folder.dart';
import 'helper/settings_provider.dart';
import 'models/folder_info.dart';
import 'package:card_loading/card_loading.dart';


Future<void> main() async {
  await SentryFlutter.init(
          (options) {
        options.dsn = 'https://825b84a08a59e95ebe2f50cc092b821e@o4504867902652416.ingest.us.sentry.io/4507411022348288';
        options.environment = 'staging';
        options.addIntegration(LoggingIntegration(minEventLevel: Level.INFO));
        // Set tracesSampleRate to 1.0 to capture 100% of transactions for performance monitoring.
        // We recommend adjusting this value in production.
        options.tracesSampleRate = 1.0;
        // The sampling rate for profiling is relative to tracesSampleRate
        // Setting to 1.0 will profile 100% of sampled transactions:
        // Note: Profiling alpha is available for iOS and macOS since SDK version 7.12.0
        options.profilesSampleRate = 1.0;

      },
      appRunner: ()=> runApp(
      // ChangeNotifierProvider(
      //   create: (context) => CustomeImageProvider(),
      //   child: const MyApp(),
      // ),

      MultiProvider(
      providers: [
              ChangeNotifierProvider(create: (context) => SettingsProvider()),
          ChangeNotifierProvider(create: (context) => LicenseProvider()),
          ChangeNotifierProxyProvider<SettingsProvider, CustomeImageProvider>(
          create: (context) => CustomeImageProvider(
          Provider.of<SettingsProvider>(context, listen: false)),
          update: (context, settingsProvider, customImageProvider) =>
          CustomeImageProvider(settingsProvider),
          ),
          ],
  child: const MyApp(),
  ),
  )
  );
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final licenseProvider = Provider.of<LicenseProvider>(context);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
        title: 'Compress Lab App',
        theme: ThemeData(
          primarySwatch: Colors.blue,
          // primaryColor: const Color(0xFFE6D7CE),
          primaryColor: const Color(0xFFFCEFEF),
          // scaffoldBackgroundColor: const Color(0xFFFCEFEF),
          scaffoldBackgroundColor: Color.fromRGBO(253, 239, 239, 1),
          textButtonTheme: TextButtonThemeData(
            style: TextButton.styleFrom(
              foregroundColor:  Colors.orange, // Set the text color for confirm buttons
            ),
          ),
          elevatedButtonTheme: ElevatedButtonThemeData(
            style: ElevatedButton.styleFrom(
              foregroundColor: Colors.white, // Set default text color
              backgroundColor: Colors.orange, // Set default background color
              // Add other default button styles as needed
            ),
          ),


          textTheme: const TextTheme(
            bodyLarge: TextStyle(color: Color(0xFF252b31)),
            bodyMedium: TextStyle(color: Colors.black54),
          ),
          appBarTheme: const AppBarTheme(
            color:  const Color(0xFFFCEFEF),
          ),
          colorScheme: ColorScheme.fromSwatch().copyWith(
            primary:   const Color(0xFFFCEFEF),
            secondary: Colors.orange,
            background: const Color(0xFFFCEFEF),
          ),
          visualDensity: VisualDensity.adaptivePlatformDensity,
        ),
        home: const SplashScreen()
        // FutureBuilder(
        //   future: licenseProvider.checkLicense(),
        //   builder: (context, snapshot) {
        //     if (snapshot.connectionState == ConnectionState.waiting) {
        //       return const Center(child: CircularProgressIndicator());
        //     } else if (licenseProvider.isLicensed) {
        //       return const SplashScreen();
        //     } else {
        //       return const LicenseExpiredScreen();
        //     }
        //   },
        // ),
        );
  }
}

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _navigateToHome();
  }

  _navigateToHome() async {

    await Future.delayed(const Duration(seconds: 3), () {});
    Navigator.pushReplacement(
      context,
      MaterialPageRoute(builder: (context) => const MyHomePage()),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Image.asset('assets/app_icon.png'),
      ),
    );
  }
}

Future<bool> showConfirmationDialog(
    BuildContext context, String title, String content) async {
  return await showDialog(
        context: context,
        builder: (BuildContext context) {
          return AlertDialog(
            title: Text(title),
            content: Text(content),
            actions: [
              TextButton(
                onPressed: () =>
                    Navigator.of(context).pop(false), // Return false
                child: const Text('Cancel'),
              ),
              TextButton(
                onPressed: () => Navigator.of(context).pop(true), // Return true
                child: const Text('Confirm'),
              ),
            ],
          );
        },
      ) ??
      false; // Return false if the dialog is dismissed
}

Future<void> showCompletionDialog(
    BuildContext context, String message, String? folderPath) async {
  showDialog(
    context: context,
    builder: (BuildContext context) {
      return AlertDialog(
        title: const Text("Operation Completed"),
        content: Text(message),
        actions: [
          if (folderPath != null)
            TextButton(
              onPressed: () {
                launchUrl(Uri.directory(folderPath));
                Navigator.of(context).pop();
              },
              child: const Text('Open Folder'),
            ),
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('OK'),
          ),
        ],
      );
    },
  );
}

class MyHomePage extends StatefulWidget {
  const MyHomePage({Key? key}) : super(key: key);

  @override
  State<MyHomePage> createState() => _MyHomePageState();
}

class _MyHomePageState extends State<MyHomePage> {
  final _pageController = PageController(initialPage: 0);
  final NotchBottomBarController _controller = NotchBottomBarController(index: 0);
  final ValueNotifier<double> _valueNotifier = ValueNotifier(0);

  Future<List<FolderInfo>>? _folderListFuture;
  final FolderService _folderService = FolderService();
  int maxCount = 3;
  String selectedDirectory ='';

  @override
  void initState() {
    super.initState();
    LicenseProvider();
    _folderListFuture = _folderService.listFolders();
  }

  @override
  void dispose() {
    _pageController.dispose();
    super.dispose();
  }

  Future<Map<String, double>> _getDiskSpaceInfo() async {
    double totalSpace = 0;
    double freeSpace = 0;
    try {
      totalSpace = (await DiskSpacePlus.getTotalDiskSpace)! / (1024 * 1024 * 1024);
      freeSpace = (await DiskSpacePlus.getFreeDiskSpace)! / (1024 * 1024 * 1024);
    } catch (e) {
      log('Error retrieving disk space info: $e');
    }
    double usedSpace = totalSpace - freeSpace;
    double usedPercentage = totalSpace != 0 ? (usedSpace / totalSpace) * 100 : 0;

    return {
      "total": totalSpace,
      "used": usedSpace,
      "free": freeSpace,
      "usedPercentage": usedPercentage,
    };
  }



  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final imageProvider = Provider.of<CustomeImageProvider>(context);


    Future<void> _pickFolderAndLoadImages(String? folderPath) async {
      await imageProvider.pickFolderAndLoadImages(folderPath: folderPath);
    }



    void _onFolderTap(String folderPath) async {
      log('folder path selected home : ${folderPath}');
      // selectedDirectory = await FilePicker.platform.getDirectoryPath(initialDirectory: folderPath);
      _pickFolderAndLoadImages(folderPath);
      setState(() async {
        _controller.jumpTo(1); // Update the bottom bar index to 1 (Compress tab)
        _pageController.jumpToPage(1); // Navigate to the Compress tab
        // selectedDirectory = folderPath;
        // await FilePicker.platform.getDirectoryPath(initialDirectory: folderPath);
        // Provider.of<CustomeImageProvider>(context).pickFolderAndLoadImages(folderPath:folderPath );
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: const Center(child: Text('Compress Lab', style: TextStyle(fontWeight: FontWeight.bold))),
        leading: IconButton(
          icon: Image.asset('assets/app_icon.png'),
          onPressed: () {},
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.video_settings),
            onPressed: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => const SettingsScreen()),
              );
            },
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.only(bottom: 80.0),
        child: PageView(
          controller: _pageController,
          physics: const NeverScrollableScrollPhysics(),
          children: [
            Column(
              children: [
                FutureBuilder<Map<String, double>>(
                  future: _getDiskSpaceInfo(),
                  builder: (context, snapshot) {
                    if (snapshot.connectionState == ConnectionState.waiting) {

                      return const CircularProgressIndicator();
                    } else if (snapshot.hasError) {
                      return const Text('Error retrieving disk space info');
                    } else if (snapshot.hasData) {
                      final data = snapshot.data!;
                      return Padding(
                        padding: const EdgeInsets.all(15.0),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            CircularSeekBar(
                              width: double.infinity,
                              height: 250,
                              progress: data["usedPercentage"]!,
                              barWidth: 8,
                              startAngle: 45,
                              interactive: false,
                              sweepAngle: 270,
                              strokeCap: StrokeCap.butt,
                              progressGradientColors: const [
                                Colors.red,
                                Colors.orange,
                                Colors.yellow,
                                Colors.green,
                                Colors.blue,
                                Colors.indigo,
                                Colors.purple
                              ],
                              innerThumbRadius: 5,
                              innerThumbStrokeWidth: 3,
                              innerThumbColor: Colors.white,
                              outerThumbRadius: 5,
                              outerThumbStrokeWidth: 10,
                              outerThumbColor: Colors.blueAccent,
                              dashWidth: 1,
                              dashGap: 2,
                              animation: true,
                              valueNotifier: _valueNotifier,
                              child: Center(
                                child: ValueListenableBuilder(
                                    valueListenable: _valueNotifier,
                                    builder: (_, double value, __) => Column(
                                      mainAxisSize: MainAxisSize.min,
                                      children: [
                                        Text('${value.round()}',
                                            style: const TextStyle(
                                                color: Colors.black45, fontWeight: FontWeight.bold)),
                                        const Text('Disk Usage ',
                                            style: TextStyle(color: Colors.black45, fontWeight: FontWeight.bold)),
                                      ],
                                    )),
                              ),
                            ),
                          ],
                        ),
                      );
                    } else {
                      return const Text('No data available');
                    }
                  },
                ),
                Expanded(
                  child: FutureBuilder<List<FolderInfo>>(
                    future: _folderListFuture,
                    builder: (context, snapshot) {
                      if (snapshot.connectionState == ConnectionState.waiting) {
                        return GridView.count(
                          crossAxisCount: 2,
                          childAspectRatio: 1,
                          crossAxisSpacing: 16.0,
                          mainAxisSpacing: 16.0,
                          children: List.generate(6, (index) => CardLoading(
                          height: 100,
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                          margin: EdgeInsets.only(bottom: 10),
                        ),),);
                        // return const Center(
                        //   child: CircularProgressIndicator(),
                        // );
                      } else if (snapshot.hasError) {
                        log('Error: ${snapshot.error}');
                        return Center(child: Text('Error: ${snapshot.error}'));
                      } else if (snapshot.hasData) {
                        final data = snapshot.data!;
                        return GridView.builder(
                          padding: const EdgeInsets.all(16.0),
                          itemCount: data.length,
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            childAspectRatio: 1,
                            crossAxisSpacing: 16.0,
                            mainAxisSpacing: 16.0,
                          ),
                          itemBuilder: (context, index) {
                            final folder = data[index];
                            return FolderCard(folder: folder, onTap: () => _onFolderTap(folder.folderPath),);
                          },
                        );
                      } else {
                        return const Center(child: Text('No image folders found.'));
                      }
                    },
                  ),
                ),
                SizedBox(height: 20),
              ],
            ),
            const CompressionScreen(),
            ImagePickerScreen(),
            ProfileScreen(),


          ],

        ),
      ),
      extendBody: true,
      bottomNavigationBar: AnimatedNotchBottomBar(
        notchBottomBarController: _controller,
        color: Colors.white,
        showLabel: true,
        notchColor: Theme.of(context).colorScheme.secondary,
        removeMargins: false,
        bottomBarWidth: 500,
        showShadow: true,
        durationInMilliSeconds: 300,
        itemLabelStyle: const TextStyle(fontSize: 10),
        bottomBarItems: [
          const BottomBarItem(
            inActiveItem: Icon(
              Icons.home_filled,
              color: Colors.black45,
            ),
            activeItem: Icon(
              Icons.home_filled,
              color: Colors.white,
            ),
            itemLabel: 'Home',
          ),
          const BottomBarItem(
            inActiveItem: Icon(
              Icons.compress,
              color: Colors.blueGrey,
            ),
            activeItem: Icon(
              Icons.compress,
              color: Colors.pink,
            ),
            itemLabel: 'Compress',
          ),

          const BottomBarItem(
            inActiveItem: Icon(
              Icons.photo_size_select_large,
              color: Color(0xFFE6D7CE),
            ),
            activeItem: Icon(
              Icons.photo_size_select_large,
              color: Color(0xFFE6D7CE),
            ),
            itemLabel: 'Resize',
          ),
          const BottomBarItem(
            inActiveItem: Icon(
              Icons.face,
              color: Color(0xFFE6D7CE),
            ),
            activeItem: Icon(
              Icons.face,
              color: Color(0xFFE6D7CE),
            ),
            itemLabel: 'Profile',
          ),
        ],
        onTap: (index) {
          log('current selected index $index');
          _pageController.jumpToPage(index);
        },
      ),
    );
  }

  double bytesToMB(int bytes) {
    return bytes / 1024 / 1024;
  }

  String formatBytesToMB(int bytes) {
    return bytesToMB(bytes).toStringAsFixed(2);
  }
}