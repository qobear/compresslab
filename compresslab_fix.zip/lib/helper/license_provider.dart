import 'dart:convert';
import 'dart:developer';

import 'package:device_info_plus/device_info_plus.dart';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

class LicenseProvider with ChangeNotifier {
  bool _isLicensed = false;
  String? _licenseCode;
  String? _nama;

  bool get isLicensed => _isLicensed;

  String? get licenseCode => _licenseCode;
  String? get nama => _nama;
  DeviceInfoPlugin deviceInfo = DeviceInfoPlugin();

  LicenseProvider() {
    _loadLicense();
  }

  Future<void> _loadLicense() async {
    final prefs = await SharedPreferences.getInstance();
    _licenseCode = prefs.getString('licenseCode');
    // _licenseCode = prefs.getBool('key');
    final licenseExpiry = prefs.getString('licenseExpiry');
    log('expired lisensi : ${licenseExpiry}');
    log('expired lisensi : ${prefs.getString('nama')}');
    if (licenseExpiry != null &&
        DateTime.parse(licenseExpiry).isAfter(DateTime.now())) {
      _isLicensed = true;
      _nama = prefs.getString('nama');
    } else {
      _isLicensed = false;
    }
    notifyListeners();
  }

  Future<void> checkLicense(String code) async {
    AndroidDeviceInfo androidInfo = await deviceInfo.androidInfo;
    var deviceId = androidInfo.device;
    log('lisensi code  ${code} dan ${deviceId}');
    final response = await http
        .get(Uri.parse('https://synelab.co.id/lead/lisensi-$code/$deviceId'));
    final data = json.decode(response.body);
    log('response check lisensi  ${data}');
    log('response check lisensi  ${data['status']}');
    if (response.statusCode == 200) {
      // final data = json.decode(response.body);
      if (data['status'] == 'success') {
        final prefs = await SharedPreferences.getInstance();
        prefs.setString('licenseCode', code);
        prefs.setString('licenseExpiry', data['data']['expiry_date']);
        prefs.setString('nama', data['data']['user']['name']);
        _licenseCode = code;
        _isLicensed = true;
      } else if (data['status'] == 'used') {
        if (data['data']['device_id'] == deviceId) {
          final prefs = await SharedPreferences.getInstance();
          prefs.setString('licenseCode', code);
          prefs.setString('licenseExpiry', data['data']['expiry_date']);
          prefs.setString('nama', data['data']['user']['name']);
          _licenseCode = code;
          _isLicensed = true;
        }
      } else {
        _isLicensed = false;
      }
    } else {
      _isLicensed = false;
    }
    notifyListeners();
  }

  Future<void> clearLicense() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.remove('licenseCode');
    prefs.remove('licenseExpiry');
    _licenseCode = null;
    _isLicensed = false;
    notifyListeners();
  }
}
